/* Stub for base/flapping.c */
void disable_service_flap_detection(service *svc) {}
void disable_host_flap_detection(host *hst) {}
void disable_flap_detection_routines(void) {}
void enable_flap_detection_routines(void) {}
void enable_service_flap_detection(service *svc) {}
void enable_host_flap_detection(host *hst) {}
